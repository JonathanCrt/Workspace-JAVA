package tp8_mlv.ex2;

public enum AppleKind {
	Golden{
		@Override
		public String toString(){
            return "Golden";
        }
	},
	Pink_Lady{
		@Override
		public String toString(){
            return "Pink Lady";
        }
	},
	Granny_Smith{
		@Override
		public String toString(){
            return "Granny Smith";
        }
	};
	
	

}



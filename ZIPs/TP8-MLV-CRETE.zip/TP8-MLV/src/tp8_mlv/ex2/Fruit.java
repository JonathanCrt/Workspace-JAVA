package tp8_mlv.ex2;

public interface Fruit {
	//Contrat :
	public double getPrice();
	public boolean equals(Object o);
	public String toString();
	
}

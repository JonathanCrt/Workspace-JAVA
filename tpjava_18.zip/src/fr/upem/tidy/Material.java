package fr.upem.tidy;

public enum Material {
	COTTON, LEATHER, SILK, SYNTHETIC
}

package fr.upem.tidy;

public interface Item {

	public String getName();

	public Material getMaterial();

	public int timeToLive();
}

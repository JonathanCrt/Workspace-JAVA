package fr.upem.tidy;

public enum Size {
	XS, S, M, L, XL, XXL, XXXL
}

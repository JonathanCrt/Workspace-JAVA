# Hanabi
Project in Java language, using ZEN5 as framework.

The actual project is for our engineering school ESIPE.

Chahinaz DINDANE and Jonathan CRETE are both in first year of they IT cycle.

## Phase 1 of project:
Really simple interface: Only two players, no blue token used, infinite option selection, both players can see theirs cards.
> A dumb version to let the players makes as many errors as they want.

## Phase 2 of project:
All the options are used.
Red tokens and blues ones are used too.
The game ends when: 1. All the red tokens are in the field,
                    2. The Deck is empty.
                    3. All the fireworks have been finished.
> A full version that can adapt a game of 2-3 and 4-5 players with all the Hanabi normal game rules.



# Hope you enjoy the game !

package fr.cretedindane.esipe.controllers;
import java.awt.*;

public enum Colors {
    RED, YELLOW, GREEN, BLUE, WHITE
}
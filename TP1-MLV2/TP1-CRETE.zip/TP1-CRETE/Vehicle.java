package fr.umlv.rental;

public interface Vehicle {
	
	int getYear();
	int calculatePrice(int year);
}


package tp4_mlv;

public class Test {
	public static void main(String[] args) {
		
		
	
		for(String arg : args) {
			System.out.println(arg);
		}
		
		/* 5) On peut en conclure qu'il est plus int�ressant d'utiliser une 
		 * boucle foreach sur un tableau ou une collection, car ceci nous dispense de tester la taille 
		 * avec la m�thode length() pour un tableau et size() pour une collection.
		 * Ceci est donc plus performant, plus optimis�  et simplifie le parcours et la syntaxe
		 */

		
	}
}

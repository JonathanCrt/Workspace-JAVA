package fr.cretedindane.esipe.bot;

public class AlwaysPlay {
}

package fr.cretedindane.esipe.bot;

public class AlwaysDrop {
}

package fr.cretedindane.esipe.action;

public enum TipType {
    COLOR, NUMBER
}

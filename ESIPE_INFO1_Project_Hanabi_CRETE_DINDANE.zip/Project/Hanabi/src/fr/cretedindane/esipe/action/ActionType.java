package fr.cretedindane.esipe.action;

public enum ActionType{
    TIP, PLAY, DROP
}
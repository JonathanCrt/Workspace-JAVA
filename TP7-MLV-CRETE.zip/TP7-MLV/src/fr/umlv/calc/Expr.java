package fr.umlv.calc;

public interface Expr {
	
	public int eval();
	public String toString();
	
}

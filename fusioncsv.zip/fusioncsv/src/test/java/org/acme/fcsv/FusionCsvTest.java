package org.acme.fcsv;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.IOException;

import org.acme.fcsv.FusionCsv;
import org.junit.Before;
import org.junit.Test;

public class FusionCsvTest {

  @Before
  public void setUp() throws Exception {
  }

  @Test
  public void testGoodFileNamesFusionCsv() {
    try {
      // tentative de création de l'instance 
      // la création de l'objet échoue si les fichiers ne sont pas trouvés
      FusionCsv fcsv = new FusionCsv("french-small.csv", "german-small.csv");
    } catch (IOException e) {
      // si on est ici, c'est qu'une exception a été lancée par le constructeur
      fail("Erreur de lecture : " + e.getMessage());
    }
  }
 
  @Test
  public void testBadFileNamesArgFusionCsv() {
    // TODO
    fail("Not implemented");
  }
  
  @Test
  public void testSimpleExportTo() {
    try {
      FusionCsv fcsv = new FusionCsv("french-client.csv", "german-client.csv");
      fcsv.exportTo("test-export.csv");
      // test l'existence du fichier
      assertTrue(new File("test-export.csv").exists());
      
    } catch (Exception e) {
      fail("Erreur export " + e.getMessage());

    } finally {
      // faire le menage (supprime le fichier créé par ce test)
      new File("test-export.csv").delete();
    }
  }

  // TODO tester les autres services
  
}

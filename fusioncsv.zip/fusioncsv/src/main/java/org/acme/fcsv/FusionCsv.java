package org.acme.fcsv;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;

public class FusionCsv {

  private String fileName1;
  private String fileName2;
  private List<Client> clients;

  public FusionCsv(String fileName1, String fileName2) throws IOException {
    this.fileName1 = fileName1;
    this.fileName2 = fileName2;
    this.clients = new ArrayList<Client>();

    Reader inFrench = new FileReader(fileName1);
    Reader inGerman = new FileReader(fileName2);

    CSVParser frenchRecords = CSVFormat.RFC4180.withFirstRecordAsHeader().parse(inFrench);
    CSVParser germanRecords = CSVFormat.RFC4180.withFirstRecordAsHeader().parse(inGerman);
    // ... à compléter
  }

  /**
   * Export au format CSV le contenu de la liste clients
   * La première ligne contient le nom des colonnes (header en ref. à RFC4180)
   * @param fileName
   * @throws IOException en cas d'erreur d'entrée/sortie
   */
  void exportTo(String fileName) throws IOException {
    FileWriter fw = new FileWriter(fileName);
    fw.write("test export fusion");
    fw.close();
  }

}
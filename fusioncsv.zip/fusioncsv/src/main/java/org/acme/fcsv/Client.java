package org.acme.fcsv;

import java.time.LocalDate;

public class Client {
  // DDD Eric Evans
  final public int id;
  final public String name;
  final public LocalDate birthday;

  public Client(int id, String name, LocalDate birthday) {
    this.id = id;
    this.name = name;
    this.birthday = birthday;
  }

  @Override
  public String toString() {
    return "Client [id=" + id + ", name=" + name + "]";
  }

  public String toCsv() {
    return id + ", " + name + ", " + birthday.toString();
  }
}



public enum ActionType{
    TIP, PLAY, DROP
}
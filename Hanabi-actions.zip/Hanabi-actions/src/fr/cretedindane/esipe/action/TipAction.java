/** could be a card or a number
    should we create an enum?
 */